#include <stdio.h>
#include "catalogo.h"
#include "estrutura.h"

//Função para o calculo de notas

int cedulas(int valor)
{ 
    int contador=0, cedulaDisponivel[7],i;
    for(i=0;i<7;i++){
        if(tipoCedulas[i].disponivel==1 && tipoCedulas[i].quantidadeCedulas){ //Verifica as cedulas disponiveis e a quantidade
            cedulaDisponivel[contador]=i;
            contador++;
        }
    }
    int numeroDeNotas[contador]; //Será guardado o número de notas de 100, 20 e 2, nessa sequencia.
    int resto;
    contador-=1;
    printf("Você receberá:\n");
    for(i=c;i>=0;i--){
        numeroDeNotas[i]=valor/tipoCedulas[cedulaDisponivel[i]].cedulas;
        resto=valor%tipoCedulas[cedulaDisponivel[i]].cedulas;
        valor=resto;
        tipoCedulas[cedulaDisponivel[i]].quantidadeCedulas-=numeroDeNotas[i];
        if(numeroDeNotas[i]!=0) {
            printf("%d notas de R$%d\n", numeroDeNotas[i], tipoCedulas[cedulaDisponivel[i]].cedulas);
        }
    }
}
