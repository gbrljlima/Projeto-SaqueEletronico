//Lista de funções

void cadastro();
int valores();
int notas();
int menu();
int subMenu();
void deposito();
int souCliente();

