/******************************************************************************
Teste manutencao


                                            Patch notes                         
Criar valores de cédulas fixas, criar condição para serem usados, fazer um for continue caso condição 0. - ok
Criar case para todos os valores, mas só permitir os que não estão sendo utilizados - ok
Colocar no inicio do código principal as notas q estão disponíveis 
colocar no inicio da manutencao a quantidade de notas disponiveis - ok
    limitar somente para as notas habilitadas - ok
Criar a reposição de notas (case 2) - repor todas de vez (melhor) ou individualmente - ok
Criar a remoção de um valor de cedula do sistema (Não é importante) - ok
Limitar a mudança max de notas para somente cedulas disponiveis - ok


Transformar o que der em funções para limpar o código - ok
Adaptar o projeto principal para rodar esse código (chato) - 70%
    - Diminuir o número de notas no saque.- ok
    - Adaptar a nota de R$5 (chato) //o problema é entre o 0 e o 5
        int valor, dez, cinco, dois, unidade;
        printf("Informe um valor: ");
        scanf("%d", &valor);
        unidade=valor%10;
        if(valor%2==0){
            dez=valor/10;
            valor%=10;
            dois=valor/2;
        }
        else if(unidade==1||unidade==5){
            dez=valor/10 - 1;
            valor= valor%10 + 10;
            cinco=valor/5 - 1;
            valor=valor%5 + 5;
            dois=valor/2;
        }
        else{
            dez=valor/10;
            valor%=10;
            cinco=valor/5;
            valor%=5;
            dois=valor/2;
        }
        printf("%d\n%d\n%d", dez, cinco, dois);
*******************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "estrutura.h"
#include "catalogo.h"

Cedulas tipoCedulas[7];

int main()
{
    int valor;
    status();
    for(int i=0;i<7;i++){ //Inicia a quantidade maxima de notas com 50 para todos os valores
        tipoCedulas[i].maxQntCedulas=50;
        tipoCedulas[i].quantidadeCedulas=50;
    }
    char repetir = 's';
    printf("Bem vindo ao caixa 24 horas!\n\n");
    do{
        printf("%d notas disponíveis de R$2\n%d notas disponíveis de R$20\n%d notas disponíveis de R$100\n", tipoCedulas[0].quantidadeCedulas, tipoCedulas[3].quantidadeCedulas, tipoCedulas[5].quantidadeCedulas);
        valor=escolherValor();
        if(valor==111000){ //Código do mantenedor
            manutencao();
            valor=0;
        }
        cedulas(valor);
        printf("Gostaria de repetir a transação? (S/N)\n");
        scanf("%s", &repetir);
    }while(repetir == 's' || repetir == 'S');

}






