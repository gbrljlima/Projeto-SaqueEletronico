#include "catalogo.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estruturas.h"
//Função para o calculo de notas
int notas(int valor)
{ 
    int numeroDeNotas[]={0,0,0}; //Será guardado o número de notas de 100, 20 e 2, nessa sequencia.
    int resto, escolhaDeNotas;
    
    numeroDeNotas[0]=valor/100; //opção com o menor número de notas
    resto=valor%100;
    numeroDeNotas[1]=resto/20;
    resto%=20;
    numeroDeNotas[2]=resto/2;
    escolhaDeNotas=1;
    printf("\nEscolha a quantidade de notas desejadas!\n");
    
    if(valor<100)
    {
        if(numeroDeNotas[2]==0)
            printf("Opção 1: %d notas de R$20\n", numeroDeNotas[1]);
        else if(valor<=20)
            printf("Opção 1: %d notas de R$2\n", numeroDeNotas[2]);
        else
            printf("Opção 1: %d notas de R$20 e %d notas de R$2\n", numeroDeNotas[1], numeroDeNotas[2]);
        if(valor>=20){
            resto=valor%100; //Uma opção mais focada na nota 2
            numeroDeNotas[1]=resto/20 - 1;
            resto=(resto%20) + 20;
            numeroDeNotas[2]=resto/2;
            if(numeroDeNotas[1]==0)
                printf("Opção 2: %d notas de R$2\n", numeroDeNotas[2]);
            else
                printf("Opção 2: %d notas de R$20 e %d notas de R$2\n", numeroDeNotas[1], numeroDeNotas[2]);
        }
    }
    else if(valor==100){
        printf("Opção 1: 1 nota de R$100\n");
        printf("Opção 2: 5 notas de R$20\n");
        printf("Opção 3: 4 notas de R$20 e 10 notas de R$2\n");
    }
    else
    { 
        printf("Opção 1: %d notas de R$100, %d notas de R$20 e %d notas de R$2\n", numeroDeNotas[0], numeroDeNotas[1], numeroDeNotas[2]);
        numeroDeNotas[0]=valor/100 - 1;//Uma opção mais focada na nota 2
        resto=valor%100 + 100;
        numeroDeNotas[1]=resto/20 - 1;
        resto=(resto%20) + 20;
        numeroDeNotas[2]=resto/2;
        printf("Opção 2: %d notas de R$100, %d notas de R$20 e %d notas de R$2\n", numeroDeNotas[0], numeroDeNotas[1], numeroDeNotas[2]);
        
        if(numeroDeNotas[2]>10){ //Uma opção mais focada na 20 com 2
            numeroDeNotas[1]+=1;
            numeroDeNotas[2]-=10;
            printf("Opção 3: %d notas de R$100, %d notas de R$20 e %d notas de R$2\n", numeroDeNotas[0], numeroDeNotas[1], numeroDeNotas[2]);
        }
        
    }
    printf("\nOpção desejada: ");
    scanf("%d", &escolhaDeNotas);
    switch(escolhaDeNotas){
        case 1:
            printf("\nOpção 1 escolhida!\nAguarde a saída das notas!\n\n");
            break;
        case 2:
            printf("\nOpção 2 escolhida!\nAguarde a saída das notas!\n\n");
            break;
        case 3:
            printf("\nOpção 3 escolhida!\nAguarde a saída das notas!\n\n");
            break;
    }
    
    usuario[numeroDaContaEntrada].saldo -= valor; //Retirando o saque do saldo do usuário
}