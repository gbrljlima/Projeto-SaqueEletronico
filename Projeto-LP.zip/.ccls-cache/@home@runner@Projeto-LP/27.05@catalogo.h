void maxCedula();
void reporTudo();
void reporIndividual();
void opcaoAddCedula();
void opcaoRemoverCedula();
int escolherValor();
int saqueCedulas();
void status();
void manutencao();

int cadastro();
int menu();
int subMenu();
void deposito();
int souCliente();
void saldo();