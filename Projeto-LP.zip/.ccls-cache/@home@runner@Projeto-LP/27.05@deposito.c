#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "catalogo.h"
#include "estrutura.h"
//Função para deposito
void deposito()
{
    float deposito;
    
    printf("Informe a quantia que você irá depositar: R$");
    int lidoComSucesso = scanf("%f", &deposito);
    while(lidoComSucesso!=1){  
      while(getchar() != '\n');
      printf("Depósito inválido!\nInforme novamente: ");
      lidoComSucesso = scanf("%f", &deposito);
    }
    
    usuario[numeroDaContaEntrada].saldo+=deposito;
    
}