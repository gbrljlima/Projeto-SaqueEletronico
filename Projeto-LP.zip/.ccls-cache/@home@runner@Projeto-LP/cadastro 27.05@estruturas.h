#include <stdio.h>
#include <stdlib.h>
#include "catalogo.h"

struct cliente{
    int numeroDaConta;
    char nome[30], endereco[50];
    float saldo;
    int senha[4];
};

extern struct cliente usuario[100];
extern int numeroDaContaEntrada;

