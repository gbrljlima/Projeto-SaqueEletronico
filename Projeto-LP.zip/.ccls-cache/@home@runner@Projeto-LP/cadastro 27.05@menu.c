#include "catalogo.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//Função para o menu
int menu()
{
    int opcao;
    printf("Escolha uma opção!\n");
    printf("(1) Não sou cliente\t (2) Sou cliente\n");
    printf("Opção: ");
    int lidoComSucesso =scanf("%d", &opcao);
    while(lidoComSucesso!=1){  
        while(getchar() != '\n');
        printf("Opção inválida!\nInforme novamente: ");
        lidoComSucesso = scanf("%d", &opcao);
    }
    return opcao;
}