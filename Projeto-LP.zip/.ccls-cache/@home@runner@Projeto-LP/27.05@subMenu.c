#include <stdio.h>
#include "catalogo.h"
//Função para o submenu
