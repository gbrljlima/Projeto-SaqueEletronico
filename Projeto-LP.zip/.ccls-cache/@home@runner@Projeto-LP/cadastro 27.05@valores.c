#include "catalogo.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "estruturas.h"
//Função para seleção de valores
int valores() //Se o usuario não tiver saldo, dar erro e voltar para o submenu
{ 
     
     //Variavel que irá guardar a conta que o usuário informar
    int escolha=0, valor=0;
    int condicaoValor=0;
    while(condicaoValor==0){
        printf("Notas disponíveis: R$2, R$20, R$100\n");
        printf("Quanto você quer retirar?\n");
        printf("(1) R$100 - (2) R$250\n");
        printf("(3) R$500 - (4) Outro valor\n");
        printf("Escolha uma opção: ");
        while(scanf("%d", &escolha)!= 1 || escolha < 1 || escolha > 4){ // Esse é o comando para impedir que o usuário coloque letras no lugar de números
            printf("Opção inválida!\nDigite a opção novamente: ");
            while(getchar() != '\n'); //limpa o buffer de entrada
                scanf("%d", &escolha);
        }
        switch(escolha){
            case 1:
                valor=100;
                return valor;
                break;
            case 2:
                valor=250;
                return valor;
                break;
            case 3:
                valor=500;
                return valor;
                break;
            case 4:
                printf("Qual valor você deseja?\n");
                while(scanf("%d", &valor)!= 1 || valor < 1 || valor%2==1){
                    printf("Não temos notas compatíveis para R$%d!\nDigite outro valor: ", valor);
                    while(getchar() != '\n'); //limpa o buffer de entrada
                        scanf("%d", &valor);
                }
                return valor;
                break;
        }
        
    }
}