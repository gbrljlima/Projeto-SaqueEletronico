/******************************************************************************
Projeto Lógica de Programação
Programa contém cadastro do cliente, opção de deposito, saque e verificação de saldo.
25/04/2023

Notas: 2,20 e 100

            ADAPTAR ESSA FUNÇÃO NO CÓDIGO PRINCIPAL (Futuro)

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "catalogo.h"
#include "estruturas.h"

struct cliente usuario[100];
int numeroDaContaEntrada;


//Função principal
int main() 
{
    int valor, condicao;
    char repetir = 's';
    do{
        printf("Bem vindo ao caixa 24 horas!\n\n");
        while(condicao == 0){ // Condicao para verificação de conta, se, no caso 2, a conta existir a condição é 1
            switch(menu()){
                case 1:
                    cadastro();
                    break;
                case 2:
                    condicao=souCliente();
                    break;
                default:
                    printf("Opção inválida!\n");
            }
        }
        do{
            switch (subMenu()){
                case 1:
                    printf("Seu saldo é: %.2f\n", usuario[numeroDaContaEntrada].saldo);
                    break;
                case 2:
                    valor = valores();
                    if(usuario[numeroDaContaEntrada].saldo < valor){
                        printf("Saldo insuficiente!\n");
                        break;
                    }
                    notas(valor);
                    break;
                case 3:
                    deposito();
                    break;
                default:
                    printf("Opção inválida!");
                    break;
            }
            printf("Gostaria de fazer outra operação? (S/N)\n");
            scanf("%s", &repetir);
        }while(repetir == 's' || repetir == 'S');
        condicao=0;
    }while(repetir != 's' || repetir != 'S');
    return 0;
    
}













